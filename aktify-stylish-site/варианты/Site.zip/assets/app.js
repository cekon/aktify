const products = [
  {title:'Крутить гайки в стесненных условиях', desc:'Подарок для человека, который любит разбираться, пробовать разные углы и не сдается после первой попытки. Задача кажется простой, но быстро превращается в настоящий механический вызов.'},
  {title:'Авторская задача: надеть кольцо', desc:'Лучший выбор для любителей логики и вау-эффекта. Получатель видит кольцо и бутылку, понимает цель — но решение придется заслужить вниманием, терпением и нестандартным мышлением.'},
  {title:'Интеллектуальный конверт для денег', desc:'Когда деньги хочется подарить красиво, а не просто в конверте. Спрячьте вложение внутри: сначала человек решает задачу, потом получает награду.'}
];
const nav = document.querySelector('.nav');
document.querySelector('.menu-btn').addEventListener('click',()=>nav.classList.toggle('open'));
const modal = document.querySelector('#productModal');
const thumbsBox = document.querySelector('.gallery-thumbs');
const imgEl = document.querySelector('.gallery-img');
const videoEl = document.querySelector('.gallery-video');
const titleEl = document.querySelector('.gallery-title');
const descEl = document.querySelector('.gallery-desc');
const stage = document.querySelector('.gallery-stage');

let current = 0;
let media = [];

const productMedia = [
  {
    title: "Крутить гайки в стесненных условиях",
    desc: "Тактильная механическая головоломка.",
    images: [
      "assets/p1/1.jpg",
      "assets/p1/2.jpg",
      "assets/p1/3.jpg"
    ],
    video: null
  },
  {
    title: "Авторская задача: надеть кольцо",
    desc: "Логическая задача с вау-эффектом.",
    images: [
      "assets/p2/1.jpg",
      "assets/p2/2.jpg"
    ],
    video: null
  },
  {
    title: "Интеллектуальный конверт",
    desc: "Подарок, который надо разгадать.",
    images: [
      "assets/p3/1.jpg",
      "assets/p3/2.jpg"
    ],
    video: null
  }
];

function openGallery(p){
  media = p.images;
  current = 0;

  titleEl.textContent = p.title;
  descEl.textContent = p.desc;

  renderThumbs();
  showMedia(0);

  modal.showModal();
}

function renderThumbs(){
  thumbsBox.innerHTML = "";

  media.forEach((src,i)=>{
    const div = document.createElement("div");
    div.className = "thumb";
    if(i===0) div.classList.add("active");

    div.innerHTML = `<img src="${src}" />`;

    div.onclick = () => showMedia(i);

    thumbsBox.appendChild(div);
  });
}

function showMedia(i){
  current = i;

  document.querySelectorAll(".thumb").forEach((t,idx)=>{
    t.classList.toggle("active", idx===i);
  });

  const src = media[i];

  videoEl.style.display = "none";
  imgEl.style.display = "block";

  imgEl.style.opacity = 0;

  setTimeout(()=>{
    imgEl.src = src;
    imgEl.style.opacity = 1;
  },150);
}

/* open modal */
document.querySelectorAll('.product-card').forEach(card=>{
  card.addEventListener('click',()=>{
    openGallery(productMedia[card.dataset.product]);
  });
});

/* close */
modal.querySelector('.close').addEventListener('click',()=>{
  modal.close();
});

/* fullscreen */
stage.addEventListener("click",()=>{
  stage.classList.toggle("fullscreen");
});
modal.querySelector('.close').addEventListener('click',()=>modal.close());
const cookie = document.querySelector('.cookie');
const cookieBtn = document.querySelector('.cookie button');

function initCookie() {
  const accepted = localStorage.getItem("cookieAccepted");

  if (accepted === "true") {
    cookie.style.display = "none";
    return;
  }

  cookie.style.display = "flex";
}

cookieBtn.addEventListener("click", () => {
  localStorage.setItem("cookieAccepted", "true");
  cookie.style.opacity = "0";

  setTimeout(() => {
    cookie.style.display = "none";
  }, 300);
});

initCookie();

/*___________________________________ Лупа____________________________________*/
const lens = document.createElement("div");
lens.className = "zoom-lens";
stage.appendChild(lens);

stage.addEventListener("mousemove",(e)=>{
  const rect = stage.getBoundingClientRect();

  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;

  const img = imgEl;

  const zoom = 2;

  lens.style.display = "block";
  lens.style.backgroundImage = `url(${img.src})`;
  lens.style.backgroundSize = `${rect.width * zoom}px ${rect.height * zoom}px`;

  const bgX = (x / rect.width) * 100;
  const bgY = (y / rect.height) * 100;

  lens.style.left = x + "px";
  lens.style.top = y + "px";

  lens.style.backgroundPosition = `${bgX}% ${bgY}%`;
});

stage.addEventListener("mouseleave",()=>{
  lens.style.display = "none";
});

/*______________________________ Full screen_________________________________*/
stage.addEventListener("dblclick",()=>{
  stage.classList.toggle("fullscreen");
});

document.addEventListener("keydown",(e)=>{
  if(e.key === "Escape"){
    stage.classList.remove("fullscreen");
  }
});
/*____________________________ Svipe__________________________________________*/
let startX = 0;

stage.addEventListener("touchstart",(e)=>{
  startX = e.touches[0].clientX;
});

stage.addEventListener("touchend",(e)=>{
  let endX = e.changedTouches[0].clientX;

  let diff = startX - endX;

  if(Math.abs(diff) > 50){
    if(diff > 0 && current < media.length - 1){
      showMedia(current + 1);
    }
    if(diff < 0 && current > 0){
      showMedia(current - 1);
    }
  }
});

/*________________________________ Preload_____________________________*/
function preload(src){
  const img = new Image();
  img.src = src;
}

function showMedia(i){
  current = i;

  document.querySelectorAll(".thumb").forEach((t,idx)=>{
    t.classList.toggle("active", idx===i);
  });

  const src = media[i];

  preload(media[i+1]);
  preload(media[i-1]);

  imgEl.style.opacity = 0;

  setTimeout(()=>{
    imgEl.src = src;
    imgEl.style.opacity = 1;
  },120);
}
